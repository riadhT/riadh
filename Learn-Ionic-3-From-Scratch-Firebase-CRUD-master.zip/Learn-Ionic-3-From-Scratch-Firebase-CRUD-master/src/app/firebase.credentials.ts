export const FIREBASE_CREDENTIALS = {
    apiKey: "your-credentials",
    authDomain: "your-credentials",
    databaseURL: "your-credentials",
    projectId: "your-credentials",
    storageBucket: "your-credentials",
    messagingSenderId: "your-credentials"
};